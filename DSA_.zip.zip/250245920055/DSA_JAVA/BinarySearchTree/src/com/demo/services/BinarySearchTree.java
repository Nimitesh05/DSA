package com.demo.services;

public class BinarySearchTree {

		Node root;
	
	 public class Node{
		
		Node left, right;
		int data;
		
		public Node(int data) {
			this.data = data;
			left = null;
			right= null;
		}
		
	}
	
//	public BinarySearchTree () {
//		root = null;
//	}
	
	public Node insertNode(Node root, int val) {
		
		root = insertData(root, val);

		
				
		
		return root;
	}

	private Node insertData(Node root, int val) {
		
		Node newNode = new Node(val);
		
		if(root == null) {
			root = newNode;
			return root;
		}
		else {
			if(val<root.data) {
				root.left = insertData(root.left, val);
			    
			}
			else {
				root.right = insertData(root.right, val);
			}
			
			return root;
		}
		 
		
		
	}
	
	public void inOrder(Node root) {
		
		if(root != null) {
			
			inOrder(root.left);
			
			System.out.print( root.data +", ");
			
			inOrder(root.right);
		}
		
	}
	
	public void postOrder(Node root)
	{
		if(root != null)
		{
			postOrder(root.left);
			postOrder(root.right);
			System.out.print(root.data+", ");
		}

	}
	
	public void preOrder(Node root)
	{
		if(root != null)
		{
			System.out.print(root.data+", ");
			preOrder(root.left);
			preOrder(root.right);
		}

	}
	
	
	
}
