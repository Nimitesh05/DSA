package com.demo.test;

import com.demo.services.BinarySearchTree;
import com.demo.services.BinarySearchTree.Node;

public class testMain{

	public static void main(String[] args) {

      BinarySearchTree bst = new BinarySearchTree();
      Node root = null;
      root = bst.insertNode(root, 8);
      root = bst.insertNode(root, 5);
      root = bst.insertNode(root, 12);
      root = bst.insertNode(root, 15);
      root = bst.insertNode(root, 10);
      root = bst.insertNode(root, 10);
      
      
      bst.inOrder(root);
     System.out.println(" ");
      bst.postOrder(root);
      System.out.println(" ");
      bst.preOrder(root);
      System.out.println(" ");
      display();
	}
	
	
	public static void display()
	{
		for(int i=0;i<5;i++)
		{
			for(int j=5-i;j>=0;j--)
			{
				System.out.print(" ");
			}
			for(int j=0;j<=i;j++)
			{
				System.out.print(j+1 +" ");
			}
			System.out.println(" ");
		}
	}
	
	
	

}
