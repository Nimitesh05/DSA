package com.demo.test;

import java.util.Arrays;

import com.demo.service.CountSort;
import com.demo.service.HeapSort;
import com.demo.service.MergeSort;
import com.demo.service.QuickSort;
import com.demo.service.SelectionSort;
import com.demo.service.SortBubble;
import com.demo.service.SortInsertion;

public class TestSort {

	public static void main(String[] args) {
		
		int[] arr2 = {1,6,9,12,7,15,6,3};
		
		
		// ---------------------- For Bubble Sort ----------------------

		//		int[]sorted=SortBubble.BubbleSort(arr2);
//		System.out.println(" ");
//		System.out.println(Arrays.toString(sorted));

		
		//---------------------- For Insertion Sort ----------------------
//		int[] sorted_by_insertion=SortInsertion.InsertionSort(arr2);
//		System.out.println(Arrays.toString(sorted_by_insertion));
	
	
		
		//---------------------- For Selection Sort ----------------------
//	     SelectionSort.selectionSort(arr2);
//		System.out.println(Arrays.toString(arr2));	
		
		
		//---------------------- For Merge Sort ----------------------
//		MergeSort.sort(arr2, 0, arr2.length-1);
//		System.out.println("final array : "+Arrays.toString(arr2));	
		
		//---------------------- For Count Sort ----------------------		
//		int [] arr=CountSort.sort(arr2);
//		System.out.println(Arrays.toString(arr));
		
		//------------------------Quick Sort---------------------
//		QuickSort.sort(arr2, 0, arr2.length-1);
		
		//----------------Heap Sort-------------------------
		HeapSort.sortHeap(arr2);
		
	}

}
