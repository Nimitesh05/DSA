     package com.demo.service;

public class SortBubble {
	
	public static int [] BubbleSort(int [] arr)
	
	{
		for(int k=1;k<arr.length;k++)
		{
			for(int i=0,j=1;j<arr.length;i++,j++)
			{
				int temp;
				if(arr[i]>arr[j])
				{
					temp=arr[i];
					arr[i]=arr[j];
					arr[j]=temp;
				}
			}
		}
		 
		return arr;
	}

}
