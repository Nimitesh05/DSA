package com.demo.service;

import java.util.Arrays;

public class HeapSort {

	public static void sortHeap(int[] arr2) {
		
		for(int i=(arr2.length/2)-1; i>=0 ; i-- )
		{
			maxheapify(arr2 , arr2.length ,i );
		}
		
		for(int i=arr2.length-1;i>=0;i--)
		{
			int temp=arr2[0];
			arr2[0]=arr2[i];
			arr2[i]=temp;
			
			maxheapify(arr2,i,0);
			
		}
		
		
	}

	private static void maxheapify(int [] arr, int len, int i ) {
		
		int left=2*i+1;
		int right=2*i+2;
		int largest=i;
		
		if(left<len && arr[left]>arr[largest]) 
		{
			largest=left;
		}
		
		if(right<len && arr[right]>arr[largest]) 
		{
			largest=right;
		}
		
		if(largest!=i)
		{
			int temp=arr[largest];
			arr[largest]=arr[i];
			arr[i]=temp;
			
			maxheapify(arr,len,largest);
		}
		System.out.println(Arrays.toString(arr));
		
	}

	 
	
	
}
