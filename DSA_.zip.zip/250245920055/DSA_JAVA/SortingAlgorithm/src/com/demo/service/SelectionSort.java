package com.demo.service;

public class SelectionSort {
    
	
	
	public static void selectionSort(int arr[]) {
		
		for(int i=0; i<arr.length-1; i++) {
			
			int last = arr.length-i-1;
			int maxInd = max(arr,0,last);
			
			swap(arr, maxInd, last);
			
			
		}
		
		//            printArray(arr);
	}

	public static int max(int[] arr, int start, int end) {
		
		int maxInd = start;
		for(int i=start; i<=end; i++) {
			if(arr[maxInd]<arr[i]) {
				maxInd=i;
			}
		}
		return maxInd;
	}
	
public static void swap(int[] arr,int first, int second) {
		
		int temp = arr[second];
		arr[second] = arr[first];
		arr[first] = temp;
		
	}
	
  public static void printArray(int[] arr) {
	  for(int i=0 ; i<arr.length; i++) {
		  System.out.println(arr[i]);
	  } 
  }
	
}
