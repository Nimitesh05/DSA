package com.demo.services;

public class SequentialSearch {

	public static int linearSearch(int n, int[] arr){
		
		

			for(int i=0; i<arr.length; i++) {
				
				if(n==arr[i]) {
					return i;
				}
				
			}
		
		
		
		return -1;
	}
	
	
}
