package com.demo.services;

public class LinkList {

	Node head;
	
	public class Node{
		Node next;
		int data;
		
		public Node(int value)
		{
			this.data=value;
			this.next=null;
		}
	}
	
	public LinkList()
	{
		head=null;
	}
	
	
	public void addNode(int value)
	{
		Node newNode=new Node(value);
		
		if(head==null)
		{
			head=newNode;
		}
		else {
			
			Node temp=head;
			while(temp.next!=null)
			{
				temp=temp.next;
			}
			
			temp.next=newNode;
		}
		
	}
	
	
	public void Display()
	{
		Node temp;
		temp=head;
		
		while(temp!=null)
		{
			System.out.print(temp.data+" , ");
			temp=temp.next;
		}
		System.out.println();
	}

	
	public void addByPosition(int value,int pos)
	{
		
		if(head==null)
		{
			System.out.println("list is empty");
		}
		else
		{
			Node newNode=new Node(value);
			if(pos==1)
			{
				newNode.next=head;
				head=newNode;
			}
			else
			{	Node temp;
				temp=head;
				int count=1;
				for(int i=1;i<pos-1;i++)
				{
					if(temp.next!=null) {
					temp=temp.next;
					count++;
					}
					
				}
				if(pos-1==count)
				{
					newNode.next=temp.next;
					temp.next=newNode;
				}
				else
				{
					System.out.println("position out of bound");
				}
				
			}
			
		}
	}


	public void addByValue(int value, int num) {
		
		if(head==null)
		{
			System.out.println("List is null.......");
		}
		else
		{
			Node temp=head;
			
			Node newNode=new Node(value);
			
			while(temp.next!=null && temp.data!=num)
			{
				temp=temp.next;
			}
			
			//check if number is present 
			if(temp.data==num)
			{
				newNode.next=temp.next;
				temp.next=newNode;
			}
			else
			{
				System.out.println("Number not found............");
			}
		}
		
	}
	
	
	public int deleteByValue(int num)
	{
		  Node temp=head;
		
		 if(head.data==num) {
			 head=temp.next;
			 temp.next=null;
			 return temp.data;
		 }
		 else {
			 
			 	Node prev = null;
			  
			 	while(temp.next!=null && temp.data != num) {
				  prev=temp;
				  temp= temp.next;  
			     }
			  
			  if(temp.data == num) {
				  prev.next=temp.next;
				  temp.next=null;
				  return temp.data;
			  }
			  else {
				  System.out.println("Value Not Found ... ");
				  return -1;
			  }
		 }
		  
		
	}
	
	public int deleteByPosition(int pos) {
		
		Node temp = head;
		
		if(pos == 1) {
			
			head = temp.next;
			temp.next=null;
			return temp.data;
		}
		else {
			
	      Node prev=null;
	      int count=1;
			
	      		for(int i=1 ; temp.next!=null && i<pos ; i++) {
	      			prev=temp;
	      			temp=temp.next;
	      			count++;
	      			}
	      		
	      		if(pos==count) {
	      			prev.next=temp.next;
	      			temp.next=null;
	      			return temp.data;
	      			}
	      		
	      		else {
	      			System.out.println("Position Not Found ... ");
	      			return -1;
	      		}
	      
		}
         

	}
	
}
