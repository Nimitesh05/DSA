package com.demo.test;

import com.demo.beans.Employee;
import com.demo.services.MyLinkList;

public class TestLinkList {

	public static void main(String[] args) {
		
//		LinkList list=new LinkList();
//		
//		list.addNode(10);
//		list.addNode(20);
//		list.Display();
//		list.addByPosition(30,1);
//		list.addByPosition(40,4);
////		list.addByPosition(50,8);
//		list.Display();
////		list.addByValue(60,70);
//		list.Display();
//		
//		System.out.println("For Delete By Position : "+list.deleteByPosition(2));
//		list.Display();
//		
//		System.out.println("For Delete By Value : "+list.deleteByValue(30));
//		list.Display();
//		
		
		System.out.println("----------------------------- For Employee --------------------------------------\n");
		
		MyLinkList list = new MyLinkList();
		
		list.addNode(new Employee(1,"Nimitesh",5000));
		list.addNode(new Employee(2,"Ajinkya",6000));
		list.addNode(new Employee(4,"Ajju",8000));
		list.addNode(new Employee(5,"Nimitesh",6000));
//		list.display();
		
		list.addByEmpNo(new Employee(3,"Paras",5500), 2);
		
//		list.display();
		
//		list.deleteByEmpno(4);
//		list.display();
		
//		list.deleteByEname("Nimitesh");
//		list.display();
		
//		list.displayBySal(5000);
		
		list.updateSalByEmpno(4, 1000);
		list.display();

	}

}
