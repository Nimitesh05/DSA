package com.demo.test;

import com.demo.service.DoublyLinkList;

public class TestDoubly {

	public static void main(String[] args) {
		
		DoublyLinkList list=new DoublyLinkList();
		list.addNode(10);
		list.addNode(20);
		list.addNode(30);
		list.addNode(40);
		list.addNode(50);
		list.addByValue(22, 20);
//		list.display();
		System.out.println("------------");
//		list.displayReverse();
		//list.display();
		
		list.deleteByValue(10);
		list.deleteByValue(30);
		list.deleteByValue(50);
		list.display();
	}

}
