package com.demo.service;

public class doublyCLL {

	Node head;
	class Node{
		
		Node next;
		Node prev;
		int data;
		
		public Node(int value)
		{
			this.data=value;
			this.next=null;
			this.prev=null;
		}
	}
	
	public void addNode(int i) {
		
		Node newNode = new Node(i);
		if(head==null)
		{
			head=newNode;
			newNode.next=newNode;
			newNode.prev=newNode;
		}
		else
		{
			Node temp=head;
			while(temp.next!=head)
			{
				temp=temp.next;
			}
			newNode.next=temp.next;
			newNode.prev=temp;
			temp.next.prev=newNode;
			temp.next=newNode;
		}
		
	}
	
	public void display()
	{
		if(head==null)
		{
			System.out.println("List is Empty.....");
		}
		else
		{
			Node temp=head;

			do{
				System.out.println(temp.data);
				temp=temp.next;
			}while(temp!=head);
		}
	}
	
	public void displayRev()
	{
		if(head==null)
		{
			System.out.println("List is Empty.....");
		}
		else
		{
			Node temp=head.prev;
			
			do{
				System.out.println(temp.data);
				temp=temp.prev;
			}while(temp!=head.prev);
		}
	}
	
	public void addByPosition(int pos , int val) {
		
		if(head == null) {
			System.out.println("List Is Empty .... ");
		}
		else {
			  Node newNode = new Node(val);
			if(pos == 1) {
				newNode.prev=head.prev;
				newNode.next=head;
				head.prev.next=newNode;
				head.prev=newNode;
				head=newNode;
			}
			else {
				Node temp=head;
				int count = 0;
				
				for(int i=0; i<pos-2 && temp.next!=head; i++) {
					temp=temp.next;
					count++;
				}
				if(count==pos-2) {
					newNode.prev = temp;
					newNode.next = temp.next;
					temp.next.prev=newNode;
					temp.next=newNode;
				}
				else {
					System.out.println("Position Out Bounds ... ");
				}
				
			}
		}
		
	}
	
	public void deleteByPosition(int pos) {
		if(head == null) {
			System.out.println("List Is empty ... ");
		}
		else {
			Node temp = head;
//			Node prev = null;
			
		    if(pos == 1) {
		    	head.next.prev=head.prev;
		    	head.prev.next=head.next;
		    	head=head.next;
		    	temp.next=null;
		    	temp.prev=null;
		    }
		    else {
		    	int count=0;
		    	
		    	for(int i=0; i<pos-1 && temp.next!=head; i++) {
		    		temp=temp.next;
		    		count++;
		    	}
		    	if(pos-1 == count) {
		    		
		    		temp.prev.next=temp.next;
		    		temp.next.prev=temp.prev;
		    		temp.prev=null;
		    		temp.next=null;
		    		
		    	}
		    	else {
		    		System.out.println("Position Out Of Bounds .... ");
		    	}
		    }
			
		}
	}

}
