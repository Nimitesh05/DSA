package com.demo.test;

import com.demo.service.doublyCLL;

public class TestDcll {
	
	public static void main(String [] args)
	{
		doublyCLL list = new doublyCLL();
		
		
		list.addNode(10);
		list.addNode(20);
		list.addNode(30);
		list.display();
		System.out.println("/////////////////");
//		list.displayRev();
		list.addByPosition(1, 9);
		list.addByPosition(4, 35);
		list.addByPosition(5, 40);
		
//		list.addByPosition(9, 80);
		list.display();
		System.out.println("/////////////////");
		list.deleteByPosition(1);
		list.deleteByPosition(2);
		list.deleteByPosition(4);
		list.deleteByPosition(9);
		list.display();
	}

}
