package com.demo.test;

import java.util.Arrays;

import com.demo.beans.My2DArray;

public class TestMy2DArray {
public static void main(String[] args) {
//	My2DArray[][] arr= new My2DArray[3][3];
	
	My2DArray obj=new My2DArray(3);
	
	
	obj.addElement();
	
	//System.out.println(obj);
	System.out.println(Arrays.deepToString(obj.getArr()));
}
}
