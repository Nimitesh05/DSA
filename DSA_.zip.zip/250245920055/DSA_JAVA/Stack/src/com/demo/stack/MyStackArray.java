package com.demo.stack;

public class MyStackArray<T> {

	T [] arr;
	int top;
	
	public MyStackArray()
	{
//		int i[] = new int[3];
		arr = (T[]) new Object [5];
		top=-1;
	}
	
	public MyStackArray(int size)
	{
		arr = (T[]) new Object [size];
		top=-1;
	}
	
	
	public boolean isEmpty()
	{
		if(top==-1)
			return true;
		else
			return false;
	}
	
	public boolean isFull()
	{
		if(top==arr.length-1)
			return true;
		else
			return false;
	}
	
	
	
	public void push(T value)
	{
		if(!isFull())
		{
			top++;
			arr[top]=value;
			System.out.println("Elment pushed is :"+value);	
		}
		else
		{
			System.out.println("Stack is Full...");
		}
		
	}
	
	
	public T pop()
	{
		if(!isEmpty())
		{
			T num=arr[top];
			top--;
			return num;
		}
		System.out.println("Stack is Empty...");
		return null;
	}
	
	
	public void display()
	{
		if(!isEmpty())
		{
			for(int i=top; i>=0 ; i--)
			{
				System.out.println(arr[i]);
			}
		}
		else
		{
			System.out.println("Stack is Empty.....");
		}
	}
}
