package com.demo.test;

import java.util.Scanner;

import com.demo.stack.MyStackList;

public class TestParanthesis {

	public static boolean checkPara(String s)
	{
		MyStackList<Character> stack = new MyStackList<>();
		
		for(int i=0;i<s.length();i++)
		{
			char c=s.charAt(i);
			
			if(c=='(' || c=='{' || c=='[')
			{
				stack.push(c);
			}
			else
			{
				if(stack.isEmpty())
				{
					return false;
				}
				else
				{
					Character ch = stack.pop();
							switch(c)
							{
							case ')':
								
								if(ch != '(')
									return false;
								break;
								
							case '}':
								
								if(ch != '{') 
									return false;
								break;
								
							case ']':
								if(ch != '[')
									return false;
								break;
							}
				}
		
		}
	}
		if(stack.isEmpty()) {
			return true;
		}else {
			return false;
		}

		
	}
	
	
	
	public static void main(String[] args) {
		
		System.out.println("enter string");
		Scanner sc=new Scanner(System.in);
		String s=sc.next();
		
		
		boolean status=checkPara(s);
		
		if(status)
		{
			System.out.println("Is a valid paranthesis");
		}
		else
		{
			System.out.println("Not a valid paranthesis");
		}
		
	}

}
