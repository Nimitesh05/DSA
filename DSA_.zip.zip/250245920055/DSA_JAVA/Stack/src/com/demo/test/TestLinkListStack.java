package com.demo.test;

import com.demo.stack.MyStackList;

public class TestLinkListStack {

	public static void main(String[] args) {
		
		MyStackList<Integer> stack=new MyStackList<>();
		
		stack.push(10);
		stack.push(20);
		stack.push(30);
		stack.display();
		System.out.println("Element popped is :"+stack.pop());
		
		System.out.println("------------------////////-------------------------------");
		
		MyStackList<String> stack1=new MyStackList<>();
		
		stack1.push("Arjun");
		stack1.push("Aniket");
		stack1.push("Duryodhan");
		stack1.display();
		System.out.println("Element popped is :"+stack1.pop());
		
		
		
	}

}
