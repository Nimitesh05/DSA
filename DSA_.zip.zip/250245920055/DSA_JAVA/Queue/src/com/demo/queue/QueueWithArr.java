package com.demo.queue;

public class QueueWithArr {

	int[] arr;
	int front, rear;
	
	public QueueWithArr() {
		arr = new int[5];
		front = -1;
		rear = -1;
	}
	
	public QueueWithArr(int size) {
		 
		arr = new int[size];
		front = -1;
		rear = -1;
	}
	
	public boolean isFull() {
		if(front==0 && rear == arr.length-1) {
			System.out.println("Queue is Full ...");
			return true;
		}
			else
		{
			if(front==rear+1) {
				System.out.println("Queue is Full ...");
			return true;}
			
			else
			return	false;
		}
	}
	
	public boolean isEmpty() {
		
		if(front == -1 && rear == -1) {
			System.out.println("Queue is Empty ... ");
			return true;
		}
		return false;
	}
	
	public void enqueue(int val) {
		if(!isFull()) {
			
			if(front==-1) {
				front=0;
			}
			rear = (rear+1)%arr.length;
			arr[rear] = val;
			
			System.out.println("Added Successfully .."+val);
		}
	}
	
	public int dequeue() {
		
		if(!isEmpty()) {
			
			int num = arr[front];
			if(front == rear) {
				front=-1;
			    rear=-1; 
			}
			else {
				   front = (front+1)%arr.length;
				}
			return num;
				
			
			
			
		}
		return -1;
	}
}
