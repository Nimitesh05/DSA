package com.demo.test;

import com.demo.queue.QueueLinkList;

public class TestQueue {

	public static void main(String[] args) {
		
		QueueLinkList qlist = new QueueLinkList();
		
		qlist.push(10);
		qlist.push(20);
		qlist.push(30);
		qlist.push(40);
		qlist.push(50);
		qlist.push(60);

		qlist.display();
		
		System.out.println("Element Popped IS : "+qlist.pop());
		
	}

}
