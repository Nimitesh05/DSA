package com.demo.test;

import com.demo.beans.MyArray;

import java.util.Arrays;
import java.util.Scanner;

public class TestMyArray {

	public static void main(String[] args) {
        MyArray arr=new MyArray(5);
        Scanner sc=new Scanner(System.in);
        for(int i=0;i<arr.getLength();i++) {
        	System.out.println("Enter "+i+"th element");
        	int n=sc.nextInt();
        	arr.add(n);
        }
        System.out.println(arr);
      System.out.println(Arrays.toString(arr.replaceIndexValue()));
        
	}

}
