 package com.demo.beans;

import java.util.Arrays;

public class MyArray {
	private int[] arr;
	private int count;
	
	public MyArray() {
		super();
		arr=new int[10];
		count=0;
	}
	public MyArray(int size) {
		super();
		arr=new int[size];
	}
	public MyArray(int[] arr) {
     super();
     this.arr=arr;
     count=arr.length;
	}
	public void add(int x) {
		if(count<arr.length) {
			arr[count]=x;
			count++;
		}
	}
	public int getLength() {
		return arr.length;
	}
	@Override
	public String toString() {
		return "MyArray [arr=" + Arrays.toString(arr) + ", count=" + count + "]";
	}
	public int getSum() {
		int sum=0;
		for(int i=0;i<arr.length;i++) {
			sum+=arr[i];
		}
		return sum;
	}
	public void rotateArray(int n) {
		if(n>=arr.length) {
			System.out.println("Rotation is not possible,n should be < "+arr.length);
		}else {
			for(int count=1;count<=n;count++) {
				      int temp=arr[0];
				for(int i=1;i<arr.length;i++) {
					arr[i-1]=arr[i];
				}
				arr[arr.length-1]=temp;
				System.out.println("Rotation-->"+count);
				System.out.println(Arrays.toString(arr));
			}
		}
	}
	
	public int[] reverseArray(boolean flag) {
		if(flag) {
			for(int i=0,j=arr.length-1;i<j;i++,j--) {
				int temp=arr[i];
				arr[i]=arr[j];
				arr[j]=temp;
			}
			return arr;
		}else {
			int[] arr1=new int[arr.length];
			for(int i=arr.length-1,j=0;i>=0;i--,j++) {
				arr1[j]=arr[i];
			}
			return arr1;
		}	
	}
	
	public int findMax() {
		int max=arr[0];
		for(int i=1;i<arr.length;i++) {
			if(max<arr[i]) {
			   max=arr[i];
			}
		}
		System.out.println(max);
		return max;
	}
	public int[] replaceIndexValue() {
		
		int max=findMax();
		
		int[] newarr=new int[max+1];
		
		for(int i=0;i<newarr.length;i++) {
			newarr[i]=-1;
		}
		
		for(int i=0;i<arr.length;i++) {
			
		     newarr[arr[i]]=i;
		     }
		return newarr;
	}
}
