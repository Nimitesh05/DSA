package com.demo.beans;

import java.util.Arrays;
import java.util.Scanner;

public class My2DArray {
	 private int[][] arr;
	 private int cR;
	 private int cC;
	 
	 
	 public My2DArray (int size) {
		super();
		arr=new int[size][size];
	 }
	 public My2DArray() {
		 super();
		 arr=new int[3][3];
		 //count=0;
		 cR=0;
		 cC=0;
	 }
	 public My2DArray(int[][] arr) {
		 super();
		 this.arr=arr;
		 //count=arr.length;
		 
		 cR=arr.length;
		 cC=arr[0].length;
		 
	 }
	 
	 Scanner sc=new Scanner(System.in);
	 
	 public void addElement(){
		 
//		 if(cR<arr.length || cC<arr[0].length) {
		 
		 System.out.println("Enter the array Elements");
			 
//			 if(cR<=arr.length)
				 for(int i=0;i<arr.length;i++)
				 {
					 for(int j=0;j<arr[0].length;j++)
					 {
						 arr[i][j]=sc.nextInt();
//						 cC++;
					 }
//					 cR++;
				 }
			 
			 
		 }

	 
	 public int getLength() {
		 return arr.length;
	 }
	@Override
	public String toString() {
		return "My2DArray [arr=" + Arrays.deepToString(arr) + "]";
	}
	
	public int[][] getArr() {
		return arr;
	}
	public void setArr(int[][] arr) {
		this.arr = arr;
	}

	 
}
