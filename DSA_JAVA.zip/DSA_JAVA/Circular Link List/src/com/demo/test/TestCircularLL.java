package com.demo.test;

import com.demo.service.circularLinkList;

public class TestCircularLL {

	public static void main(String[] args) {
		
		circularLinkList list = new circularLinkList();
		
		list.addNode(10);
		list.addNode(15);
		list.addNode(20);
		list.addNode(25);
		list.addNode(30);
//		list.addByPosition(9,1);
//		list.addByPosition(11,3);
//		list.addByPosition(31,8);
//		list.addByPosition(1,20);
		list.display();
		System.out.println("------------");
		list.deleteByPosition(1);
		list.display();
	}

}
