package com.demo.service;

public class circularLinkList {
	
	Node head;
	class Node{
		Node next;
		int data;
		
		public Node(int value)
		{
			this.data=value;
			this.next=null;
		}
	}
	
	
	public void addNode(int value)
	{
		Node newNode= new Node(value);
		if(head==null)
		{
			head = newNode;
			head.next = newNode;
		}
		else
		{
			Node temp = head;
			
			while(temp.next!=head)
			{
				temp = temp.next;
			}
			
			newNode.next = temp.next;
			temp.next = newNode;
		}
		
	}
	
	public void addByPosition(int value, int pos)
	{
		if(head==null)
		{
			System.out.println("List is Empty.....");
		}
		else
		{
			Node temp=head;
			Node newNode = new Node(value);
			if(pos==1)
			{
				newNode.next=head;
				
				while(temp.next!=head)
				{
					temp=temp.next;
				}
				
				temp.next=newNode;
				head=newNode;
			}
			
			else 
			{
				int count=0;
				for(int i=0;i<pos-2 && temp.next!=head;i++)
				{
					temp=temp.next;
					count++;
				}
				
				if(count==pos-2)
				{
					newNode.next=temp.next;
					temp.next=newNode;
				}
				else
				{
					System.out.println("position out of Bound....");
				}
				
			}
		}
	}
	
	public void deleteByPosition(int pos)
	{
		if(head==null)
		{
			System.out.println("List is Empty...");
		}
		else
		{
			Node temp=head;
			Node prev=null;
			if(pos==1)
			{
				
				while(temp.next!=head)
				{
					temp=temp.next;
					
				}
				temp.next=head.next;
				head.next=null;
				head=temp.next;
				
				
			}
			else
			{
				int count=0;
				for(int i=0;i<pos-1 && temp.next!=head;i++)
				{
					prev=temp;
					temp=temp.next;
					count++;
				}
				
				if(count==pos-1)
				{
					prev.next=temp.next;
					temp.next=null;
				}
				else
				{
					System.out.println("Position out of Bound");
				}
				
			}
		}
	}
	
	public void display()
	{
		if(head==null)
		{
			System.out.println("List is Empty............");
		}
		else
		{
			Node temp=head;

			do{
				System.out.println(temp.data);
				temp=temp.next;
			}while(temp!=head);
			
		}
	}
	
	
}
