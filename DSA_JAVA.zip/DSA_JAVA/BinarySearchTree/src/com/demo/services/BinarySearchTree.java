package com.demo.services;

public class BinarySearchTree {

		Node root;
	
	 public class Node{
		
		Node left, right;
		int data;
		
		public Node(int data) {
			this.data = data;
			left = null;
			right= null;
		}
		
	}
	
	public BinarySearchTree () {
		root = null;
	}
	
	public Node insertNode( int val) {
		
		root = insertData(root, val);

		
				
		
		return root;
	}

	private Node insertData(Node root, int val) {
		
		Node newNode = new Node(val);
		
		if(root == null) {
			root = newNode;
			return root;
		}
		else {
			if(val<root.data) {
				root.left = insertData(root.left, val);
			    
			}
			else {
				root.right = insertData(root.right, val);
			}
			
			return root;
		}
		 
		
		
	}
	
	public void inOrderTraverSal() {
		inOrder(root);
	}
	
	public void preOrderTraverSal() {
	    preOrder(root);
	}
	
	public void postOrderTraverSal() {
		postOrder(root);
	}
	
	public void inOrder(Node root) {
		
		if(root != null) {
			
			inOrder(root.left);
			
			System.out.print( root.data +", ");
			
			inOrder(root.right);
		}
		
	}
	
	public void postOrder(Node root)
	{
		if(root != null)
		{
			postOrder(root.left);
			postOrder(root.right);
			System.out.print(root.data+", ");
		}

	}
	
	public void preOrder(Node root)
	{
		if(root != null)
		{
			System.out.print(root.data+", ");
			preOrder(root.left);
			preOrder(root.right);
		}

	}
	
	public boolean search(int val) {
		return searchBinaryTree(root, val);
	}
	
	public boolean search_NoN_Recursive(int num)
	{	
		return search_non_recur_BinaTree(root, num);
	}
	
	private boolean search_non_recur_BinaTree(Node root, int num)
	{
		//check if root is null
		if(root!=null)
		{
			Node temp = root;
			while(temp!=null)
			{
				if(temp.data == num)
				{
					return true;
				}
				else if(temp.data > num)
				{
					temp=temp.left;
				}
				else
				{
					temp = temp.right;
				}
			}
			
		}
		return false;
	}

	public boolean searchBinaryTree(Node root , int val) {
		
		if(root != null){
			
			if(root.data == val ) {
				
				return true;
			}
			else {
				if(root.data > val) {
					return searchBinaryTree(root.left, val);
				}
				else {
					return searchBinaryTree(root.right, val);
				}
			}
			
		}
		
		return false;
		
		
	}
	
}
