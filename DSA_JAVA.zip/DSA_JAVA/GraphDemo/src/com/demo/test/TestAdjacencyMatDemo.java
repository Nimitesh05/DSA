package com.demo.test;

import com.demo.services.AdjacencyListDemoMatrix;

public class TestAdjacencyMatDemo {

	public static void main(String[] args) {
		
		AdjacencyListDemoMatrix mat = new AdjacencyListDemoMatrix(2);
		
		mat.addGraph();
		
		mat.display();
		
		mat.bfs(0);
		
	}

}
