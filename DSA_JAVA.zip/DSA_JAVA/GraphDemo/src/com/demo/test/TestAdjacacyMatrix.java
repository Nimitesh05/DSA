package com.demo.test;



import com.demo.services.AdjacencyMatrixDemo;

public class TestAdjacacyMatrix {

	public static void main(String[] args) {
		
		AdjacencyMatrixDemo mat = new AdjacencyMatrixDemo();
		
		mat.addGraph();
		
		System.out.println();
		
		mat.displayGraph();
	}

}
