package com.demo.services;

import java.util.Arrays;
import java.util.Scanner;

public class AdjacencyListDemoMatrix {

	Node[] heads;
	
	class Node{
		
		int data;
		Node next;
		
		public Node(int data) {
			this.data = data;
			this.next = null;
		}
	}
	
	public AdjacencyListDemoMatrix(int s) {
		heads= new Node[s];
	}
	
	public void addGraph() {
		Scanner sc = new Scanner(System.in);
		for(int i=0; i<heads.length; i++) {
			
			for(int j=0 ; j<heads.length; j++) 
			{
				System.out.println("Enter the Edge "+i+" -------> "+j+" : ");
				int num = sc.nextInt();
				
				if(num==1) {
					Node newNode = new Node(j);
					if(heads[i]==null) {
						heads[i]=newNode;
					}
					else {
						newNode.next=heads[i];
						heads[i]=newNode;
					}
				}
				
			}
			
			
		}
		
	}
	
  public void display() {
	  
	  for(int i=0; i<heads.length; i++){
		 
		  System.out.print("Node :"+i+ " --------->");
		  Node temp = heads[i];
		 
		  while(temp != null) {
			  
			  System.out.print(temp.data + "  ");
			  temp=temp.next;
		  }
		  System.out.println();
	  }
  }	
  
  
  public void dfs(int n) {
	  
	  boolean[] visited = new boolean[heads.length];
	  
	  MyStackList<Integer> myStack = new MyStackList<>();
	  
	  int[] dfs = new int[heads.length];
	  
	  for(int i=0;i<visited.length; i++) {
	    visited[i]=false;	  
	  }
	  
      myStack.push(n);
      
      int count =0;
      while(!myStack.isEmpty()){
    	  
    	  int d = myStack.pop();
    	  
    	  if(!visited[d]) {
    		  
    		  visited[d]=true;
    		  
    		  dfs[count]=d;
    		  
    		  count++;
    		  
    		  Node temp = heads[d];
    		  
    		  while(temp!=null) {
    			  
    			  if(!visited[temp.data]) {
    				 myStack.push(temp.data); 
    				
    			  }
    			  temp=temp.next;
    		  }
    	  }
    	  System.out.println("------------------------------------------------");
        myStack.display();
        System.out.println("------------------------------------------------");
        System.out.println("Visted : "+ Arrays.toString(visited));  
      System.out.println("------------------------------------------------");
      System.out.println("dfs : "+Arrays.toString(dfs));
      System.out.println("------------------------------------------------");
      }
      System.out.println("------------------------------------------------");
     System.out.println("Final dfs : "+Arrays.toString(dfs));
  }
  
  
  public void bfs(int n)
  {
	boolean [] visited = new boolean [heads.length];
	int [] bfs = new int [heads.length];
	
	QueueLinkList list = new QueueLinkList();
	
	list.enQueue(n);
	
	for (int i=0; i<visited.length;i++)
	{
		visited[i]=false;
	}
	
	int count=0;
	while(!list.isEmpty())
	{
		int e = list.deQueue();
		
		if(!visited[e])
		{
			visited[e]=true;
			
			bfs[count] = e;
			
			count++;
			
			Node temp=heads[e];
			while(temp!=null)
			{
				if(!visited[temp.data])
				{
					list.enQueue(temp.data);
				}
				temp = temp.next;
			}
		}
		System.out.println(Arrays.toString(visited));
		list.display();
		System.out.println(Arrays.toString(bfs));
	}
	
  }

}
