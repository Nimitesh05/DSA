package com.demo.services;

import java.util.Scanner;

public class AdjacencyMatrixDemo {

	int[][] graph;
	
	public AdjacencyMatrixDemo(){
		graph = new int [4][4];
	}
	
	public AdjacencyMatrixDemo(int size) {
		graph = new int[size][size];
	}
	
	public void addGraph() {
		for(int i =0; i<graph.length; i++) {
			
			for(int j = 0 ; j<graph[i].length; j++) {
			    Scanner sc = new Scanner(System.in);
				System.out.println("Enter Edge "+i+" ---------> "+j+" : ");
		        graph[i][j] = sc.nextInt();
			}
			
			
		}
	}
	
	public void displayGraph() {
		for(int i =0; i<graph.length; i++) {
			
			for(int j = 0 ; j<graph[i].length; j++) {
			   
				System.out.print(graph[i][j]+ "\t");
			}
			System.out.println();
			
		}
	}
	
}
