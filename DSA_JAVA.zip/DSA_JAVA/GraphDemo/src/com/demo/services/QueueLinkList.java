package com.demo.services;

public class QueueLinkList {

	Node front;
	Node rear;
	
	class Node{
		
		int data;
		Node next;
		
		public Node(int data) {
			this.data = data;
			this.next=null;
		}
		
	}
	
	public QueueLinkList() {
		front = null;
		rear = null;
	}
	
	public boolean isEmpty() {
		if(front == null || rear==null) {
		 return true;
		}
		else 
			return false;
	}
	
	public void enQueue(int value) {
		Node newNode = new Node(value);
		if(!isEmpty()) {
			rear.next=newNode;
			rear=newNode;
		}
		else {
			front = newNode;
			rear = newNode;
		}
		
	}
	
	public int deQueue() {
		
		if(isEmpty())
		{
			System.out.println("Queue Is Empty ... ");
			return -1;  
		}
		else 
		{
			Node temp=front;
			int num=front.data;
			front=front.next;
			temp.next=null;
			return num;
		}
		
	}
	
	public void display() {
		
		if(isEmpty()) {
			System.out.println("Queue is Empty");
		}
		else{
			Node temp=front;
			
			while(temp!=null) {
				System.out.println(temp.data);
			   temp=temp.next;
			}
			System.out.println();
		}
		
	}
	
}
