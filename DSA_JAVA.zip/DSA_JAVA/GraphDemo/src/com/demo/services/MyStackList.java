package com.demo.services;

public class MyStackList <T> {

	Node top;
	class Node{
		T data;
		Node next;
		
		public Node(T value)
		{
			this.data=value;
			this.next=null;
		}
	}
	
	public MyStackList()
	{
		top=null;
	}
	
	public boolean isEmpty()
	{
		if(top==null)
			return true;
		else
			return false;
	}
	
	public void push(T value)
	{
		Node newNode= new Node(value);
		if(!isEmpty())
		{
			newNode.next=top;
		}	
		top=newNode;
		
		System.out.println("Pushed :"+newNode.data);
		
	}
	
	public void display()
	{
		if(isEmpty())
		{
			System.out.println("Stack is Empty....");
		}
		else
		{
			Node temp=top;
			while(temp!=null)
			{
				System.out.println(temp.data);
				temp=temp.next;
			}
			
		}
	}
	
	
	public T pop()
	{
		if(!isEmpty())
		{
			Node temp=top;
			top=temp.next;
			temp.next=null;
			return temp.data;
		}
		System.out.println("Stack is Empty.....");
		return null;
	}
}
