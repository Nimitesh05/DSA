package com.demo.service;

public class HashTable {

Node [] heads;
	class Node
	{
		Node next;
		int data;
		
		public Node(int value)
		{
			this.data=value;
			this.next=null;
		}
}
	public HashTable()
	{
		heads = new Node [5];
	}
	
	public HashTable(int size)
	{
		heads = new Node [size];
	}
	
	public void insertData(int val) {
		Node newNode = new Node (val);
		int index = val%heads.length;
		
		if(heads[index] == null) {
			heads[index]=newNode;
		}
		else {
			newNode.next = heads[index];
			heads[index]=newNode;
		}
	}
	
	public void searchData(int value)
	{
		int index=value%heads.length;
		
		Node temp=heads[index];
		while(temp!=null && temp.data!=value)
		{
			temp=temp.next;
		}
		if(temp.data==value)
		{
			System.out.println(value+" found at Bucket "+index);
		}
		else
		{
			System.out.println("Number not found");
		}
	}
	
	public void displayData() 
	{
  	  for(int i=0;i<heads.length;i++) 
  	  {
  		  Node temp=heads[i];
  		  System.out.print(i+"---->");
  		  
  		  while(temp!=null)
  		  {
  			  System.out.print(temp.data+"---->");
  			  temp=temp.next;
  		  }
  		  
  		  System.out.print("null\n");
  		  
  		  
  	  }
	
   }
}