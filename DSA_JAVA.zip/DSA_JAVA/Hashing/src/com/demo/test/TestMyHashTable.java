package com.demo.test;

import com.demo.service.HashTable;

public class TestMyHashTable {

	public static void main(String[] args) {
		
		HashTable ht = new HashTable();
		
//		ht.insertData(99);
//		ht.insertData(1);
//		ht.insertData(5);
//		ht.insertData(23);
//		ht.insertData(77);
//		ht.insertData(15);
//		ht.insertData(19);
//		
//		ht.displayData();
//		
//		ht.searchData(99);
		for(int i=0;i<50;i++)
		{
			ht.insertData(i);
		}
		ht.displayData();
		
		ht.searchData(28);
	}

}
