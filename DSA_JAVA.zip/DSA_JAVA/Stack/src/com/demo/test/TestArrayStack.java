package com.demo.test;

import com.demo.stack.MyStackArray;

public class TestArrayStack {

	public static void main(String[] args) {
		
//		Scanner sc=new Scanner(System.in);
//		System.out.println("Enter size of Stack.");
//		int size=sc.nextInt();
//		MyStackArray stack1 = new MyStackArray(size);
		
		MyStackArray<Integer> stack = new MyStackArray<>();
		stack.push(10);
		stack.push(20);
		stack.push(30);
		stack.push(40);
		stack.push(50);
		stack.push(60);
		stack.display();
		System.out.println("Element popped is : "+stack.pop());

	}

}
