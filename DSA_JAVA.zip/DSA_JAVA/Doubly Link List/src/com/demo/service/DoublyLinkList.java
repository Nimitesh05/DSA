package com.demo.service;

public class DoublyLinkList {

	Node head;
	class Node{
		Node next;
		Node prev;
		int data;
		
		public Node (int data)
		{
			this.data=data;
			this.next=null;
			this.prev=null;
		}
	}
	
	public void addNode(int value)
	{
		Node newNode = new Node(value);
		
		if(head==null)
		{
			head=newNode;
		}
		
		else
		{
			Node temp;
			temp=head;
			
			while(temp.next!=null)
			{
				temp=temp.next;
			}
			
			temp.next=newNode;
			newNode.prev=temp;
		}
	}
	
	
//--------------------------------ADD After VALUE --------------------------------
	public void addByValue(int value,int num)
	{
		if(head==null)
		{
			System.out.println("List is empty........");
		}
		else
		{
			Node newNode = new Node(value);
			Node temp=head;
			
			while(temp.next!=null && temp.data!=num)
			{
				temp=temp.next;
			}
			
			if(temp.data==num)
			{
				newNode.prev=temp;
				newNode.next=temp.next;
		          if(temp.next!=null) {
					temp.next.prev=newNode;
				}
				temp.next=newNode;
			}
			else
			{
				System.out.println("Number not found in list.....");
			}
			
		}
	}
	
	// ---------------------------- Delete By value 
	
	public void deleteByValue(int value) {
		
		if(head == null) {
			System.out.println("List Is Empty ... ");
		}
		else {
			Node temp = head;
			if(head.data == value) {
				head = head.next;
				temp.next.prev=null;
				temp.next=null;
			}
			else {
				
				while(temp.next!=null && temp.data != value) {
					temp=temp.next;
				}
				if(temp.data == value) {
					temp.prev.next = temp.next;
					
					if(temp.next!=null) {
						temp.next.prev= temp.prev;
					}
					
					temp.next=null;
					temp.prev=null;
				}
				else {
					System.out.println("Value Not Found");
				}
			}
		}
		
	}
	
	
//------------------------- Display Function -----------------
	public void display()
	{
		if(head==null)
		{
			System.out.println("list is empty.....");
		}
		else {
			Node temp = head;
			while(temp!=null)
			{
				System.out.println(temp.data);
				temp=temp.next;
			}
		}
	}
	
//-------------------Display in reverse--------------------
	public void displayReverse()
	{
		if(head==null)
		{
			System.out.println("List is Empty");
		}
		else
		{
			Node temp=head;
			
			while(temp.next!=null){
				temp=temp.next;
			}
			
			while(temp!=null)
			{
				System.out.println(temp.data);
				temp=temp.prev;
			}
		}
	}
	
}

