package com.demo.services;

import com.demo.beans.*;

public class MyLinkList {

   Node head;
 
   class Node{
	   
	   Employee data;
	   Node next;
	
	   public Node(Employee data) {
		super();
		this.data = data;
		this.next = null;
	   }
   }

   
public MyLinkList() {
	super();
	this.head = null;
}
   
   public void addNode(Employee ob) {
	   Node newNode =new Node(ob);
	   if(head == null) {
		   head= newNode;
	   }
	   else {
		   
		   Node temp=head;
		   
		   while(temp.next!= null) {
			   temp=temp.next;
		   }
		   
		   temp.next=newNode;
	   }
   }
	
   public void addByEmpNo(Employee ob, int empno) {
	   
	   if(head==null) {
		   System.out.println("LiSt Is Empty");
	   }
	   else {
		   Node newNode = new Node(ob);
		   Node temp=head;
		   
		   while(temp.next != null && temp.data.getId() != empno) {
			   temp=temp.next;
		   }
		   
		   if(temp.data.getId()==empno) {
			   newNode.next=temp.next;
			   temp.next=newNode;
			   
		   }
		   else {
			   System.out.println("EmpNo No Not Found .... ");
		   }
	   }
	   
   }
   
   public Employee deleteByEmpno(int empno) {
	   
	   if(head == null) {
		   System.out.println("List Is Empty ... ");
		   return null;
	   }
	   else {
		   Node temp=head;

		   if(head.data.getId()==empno) {
			   head=temp.next;
			   temp.next=null;
			   return temp.data;
		   }
		   else{
			   Node prev=null;
			   while(temp.next!=null && temp.data.getId() != empno) {
				    prev = temp;
				   temp=temp.next;
			   }
			   
			   if(temp.data.getId()==empno) {
				   prev.next=temp.next;
				   temp.next=null;
				   return temp.data;
			   }
			   else {
				   System.out.println("EmpNo Not Found ... ");
				   return null;
			   }
		   }
	   }
   }
   
   
   //delete all nodes with given empname
   public void deleteByEname(String ename)
   {
	   if(head==null)
	   {
		   System.out.println("List is Empty............");
	   }
	   else
	   {
		   Node temp=head;
		   Node prev=null;
		   
		   while(temp!=null) {
			   
			   while(temp.next!=null && !temp.data.getName().equals(ename))
			   {   
			      prev=temp;
			      temp=temp.next;
			   }
			   
			   if(head.data.getName().equals(ename))
			   {
				   head=temp.next;
				   temp.next=null;
				   temp=head;
			   }
			   else
			   {
				   
				   if(temp.data.getName().equals(ename)) 
				   {
					   prev.next=temp.next;
					   temp.next=null;
					   temp=prev.next;
				   }
				   
				   else
				   {
					   System.out.println("Ename Not Found ...");
				   }
			  }
		   }
		   
	   }
   }
   
   
   // update sal based on empno
   
   
   public void updateSalByEmpno(int empno, int sal) {
	
	   if(head == null) {
		 System.out.println("List is empty.......");  
	   }
	   else
	   {
		   Node temp=head;
		   
		   while(temp.next!=null && temp.data.getId()!=empno)
		   {
			   temp=temp.next;
		   }
		   
		   if(temp.data.getId()==empno)
		   {
			   temp.data.setSal(sal);
		   }
		   else
		   {
			   System.out.println("Employee not Found...");
		   }
	   }
	   
   }
   
   //display all nodes with salary > given salary
   public void displayBySal(int sal)
   {
	   if(head==null)
	   {
		   System.out.println("list is empty........");
	   }
	   
	   else
	   {
		   Node temp=head;
		   while(temp!=null)
		   {
			   if(temp.data.getSal()>sal)
			   {
				 System.out.println(temp.data);  
			   }
			   temp=temp.next;
		   }
		   
	   }
	   
   }    
   
   
   public void display() {
	   Node temp=head;
      while(temp != null) {
    	  System.out.println(temp.data);
    	  temp=temp.next;
      }
      System.out.println();
   }


   
}
