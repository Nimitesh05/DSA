package com.demo.service;

import java.util.Arrays;

public class CountSort {

	public static int [] sort(int[] arr2) {
		
		//Find max element in array.
		int max=findMax(arr2);
		System.out.println("Max : "+ max);
		
		//create array of size max+1
		int [] brr=new int [max+1];
		
		//insert 0 at all positions 
//		for(int i=0;i<brr.length;i++)
//		{
//			brr[i]=0;
//		}
		
		//insert 1 at index of brr
		for(int i=0;i<arr2.length;i++)
		{
			brr[arr2[i]]++;
		}
		System.out.println(Arrays.toString(brr));
		
		//cumulative count in created array
		for(int i=1;i<brr.length;i++)
		{
			brr[i]=brr[i-1]+brr[i];
		}
		System.out.println(Arrays.toString(brr));
		
		
		//create new array and insert values.
		int [] new_arr = new int [arr2.length];
		for(int i=0;i<arr2.length;i++)
		{
			int value=arr2[i];
			
			new_arr[brr[value]-1]=value;
			brr[arr2[i]]--;
		}
		System.out.println(Arrays.toString(arr2));
	
		return new_arr;
	}

	
	
	
	private static int findMax(int[] arr2) {
		
		int max=arr2[0];
		for(int m : arr2)
		{
			if(max<m)
			{
				max=m;
			}
		}
		return max;
	}
	
	

}
