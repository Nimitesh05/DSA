package com.demo.service;

import java.util.Arrays;

public class MergeSort {

	public   static void sort (int[] arr, int l , int h) {
		
		if(l<h) {
			
			// Find mid Element ...
			int mid = (int) (l+h)/2;
			
			// for left Array  ....
			sort(arr,l,mid);
			
			// for Right Array ....
			sort(arr, mid+1, h);
			
			// for Merge Array Logic
			merge(arr, l, mid, h);
			
		}
		
	}

	private static void merge(int[] arr, int l, int mid, int h) {
		
		// find the Sizes Of Two Array ....
		
		int n1 = mid - l + 1;
		int n2 = h  - mid;
		
		// define Array 
		
		int[] larr = new int[n1];
		int[] rarr = new int[n2];
		
		// for copy data in temp arrays
		
		for(int i=0; i<n1; i++)
		{
			larr[i] = arr[l+i];
		}
		
		for(int i=0; i<n2; i++) 
		{
			rarr[i] = arr[mid+1+i];
		}
		
		// sort algo logic 
		
        int i=0, j=0;
        
        int k=l;
        
        while(i<n1 && j<n2) {
        	
        	if(larr[i]<=rarr[j]) {
        		arr[k] = larr[i];
        		i++;
        	}
        	else
        	{
        		arr[k]=rarr[j];
        		j++;
        	}
        	
        	k++;
        }
               
        // sort remaining array
        
        while(i<n1) {
        	arr[k] = larr[i];
    		i++;
    		k++;
        	
        }
		
        while(j<n2) {
        	arr[k] = rarr[j];
    		j++;
    		k++;
        	
        }
	
	   System.out.println(Arrays.toString(arr));
	}
	
	
}
