package com.demo.service;

import java.util.Arrays;

public class QuickSort {

	public static void sort(int[] arr, int start , int end ) {
		
		if(start<end) {
			
		 int pos = partition(arr, start, end);
			
		 sort(arr, start, pos-1);	
		 
		 sort(arr, pos+1, end );
		 
		}
		
		
	}

	private static int partition(int[] arr, int start, int end) {
		
		int i = start;
		
		int j = end;
		
		int pivot = start;
		
		
		while(i<j) {
			
			while(i<end && arr[i]<=arr[pivot]) {
				i++;
			}
			
			while(j>pivot && arr[j]>arr[pivot]) {
				j--;
			}
			
			
			if(i<j) {
				
				int temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
				
			}
			
		}
		
			int temp = arr[pivot];
			arr[pivot] = arr[j];
			arr[j] = temp;
	
		
			
				
				
		
		
		
		
		
		System.out.println(Arrays.toString(arr));
		return j;
		
	}
	
	
}
