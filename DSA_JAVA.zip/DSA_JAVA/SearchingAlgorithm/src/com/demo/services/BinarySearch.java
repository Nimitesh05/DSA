package com.demo.services;

public class BinarySearch {
   
	public static int binarySearch(int n, int l, int h, int[] arr) {
//		 Recursive method...

		if(h>=l) {
			int mid = (int) (l+h)/2;
			
			if(arr[mid]==n) {
				return mid;
			}
			else if(arr[mid]< n) {
				l=mid+1;
			  return binarySearch(n, l, h, arr);
			}
			else if(arr[mid]>n) {
				h=mid-1;
			 return binarySearch(n, l, h, arr);
			}
			
			
		}
		
		
		return -1;
	}
	
	public static int binarySearch1(int n,int [] arr)
	{
		// Non Recursive method...
		int low=arr[0];
		int high=arr.length-1;
		
		
		while(low<=high)
		{
			int mid=(low+high)/2;
			
			if(arr[mid]==n)
			{
				return mid;
			}
			else if(arr[mid]>n)
				high=mid-1;
			
			else if(arr[mid]<n)
				low=mid+1;
		}
		return -1;
	}
	 
}
