package com.demo.test;

import java.util.Scanner;

import com.demo.services.BinarySearch;
import com.demo.services.SequentialSearch;

public class SearchAlgoTest {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		//sequential search ...........
		
		int[] arr = {25,14,79,36,56};
		
		System.out.println("Enter The no to search :");
		int n = sc.nextInt();
		
		int index=SequentialSearch.linearSearch(n, arr);
		if(index != -1) 
		{
			System.out.println("Element found at index: "+index);
		}
		else
		{
			System.out.println("Element Not Found :");
		}
		
		
		
		// Binary Search........................
		int[] arr1 = {1,4,6,9,12,16,18,22,36};
		
		System.out.println("Enter the No. : ");
		int n1=sc.nextInt();
		int index1=BinarySearch.binarySearch1(n1, arr1);
		if(index1 != -1) 
		{
			System.out.println("Element found at index: "+index1);
		}
		else
		{
			System.out.println("Element Not Found :");
		}
	

		
		
		
	}

	
	
	
	
}
