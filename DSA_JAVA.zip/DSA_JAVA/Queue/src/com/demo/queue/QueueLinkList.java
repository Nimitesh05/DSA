package com.demo.queue;

public class QueueLinkList <T>{

	Node front;
	Node rear;
	
	class Node{
		
		T data;
		Node next;
		
		public Node(T data) {
			this.data = data;
			this.next=null;
		}
		
	}
	
	public QueueLinkList() {
		front = null;
		rear = null;
	}
	
	public boolean isEmpty() {
		if(front == null || rear==null) {
		 return true;
		}
		else 
			return false;
	}
	
	public void enQueue(T value) {
		Node newNode = new Node(value);
		if(!isEmpty()) {
			rear.next=newNode;
			rear=newNode;
		}
		else {
			front = newNode;
			rear = newNode;
		}
		
	}
	
	public T deQueue() {
		if(isEmpty()) {
			System.out.println("Queue Is Empty ... ");
		  return null;  
		}
		else {
			Node temp=front;
			T num=front.data;
			front=front.next;
			temp.next=null;
			return num;
		}
		
	}
	
	public void display() {
		
		if(isEmpty()) {
			System.out.println("Queue is Empty");
		}
		else{
			Node temp=front;
			
			while(temp!=null) {
				System.out.println(temp.data);
			   temp=temp.next;
			}
			System.out.println();
		}
		
	}
	
}
