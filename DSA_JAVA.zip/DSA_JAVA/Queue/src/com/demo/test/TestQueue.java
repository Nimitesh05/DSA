package com.demo.test;

import com.demo.queue.QueueLinkList;

public class TestQueue {

	public static void main(String[] args) {
		
		QueueLinkList<Integer> qlist = new QueueLinkList<>();
		
		qlist.enQueue(10);
		qlist.enQueue(20);
		qlist.enQueue(30);
		qlist.enQueue(40);
		qlist.enQueue(50);
		qlist.enQueue(60);

		qlist.display();
		
		System.out.println("Element Dequeue Is : "+qlist.deQueue());
		
	}

}
